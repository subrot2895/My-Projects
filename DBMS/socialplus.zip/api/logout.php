<?php
$_SESSION = array();
session_destroy();
unset($_COOKIE['SocialPlusLogin']);

?>